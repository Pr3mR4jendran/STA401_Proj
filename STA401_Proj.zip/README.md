# STA401_Proj
Course Project for STA401: Introduction to Data Mining.
